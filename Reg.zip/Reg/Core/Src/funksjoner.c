/*
 * funksjoner.c
 *
 *  Created on: Jan 20, 2022
 *      Author: trcho
 */


#include "main.h"
#include <math.h>
#include <structures.h>
#include <funksjoner.h>
#include <string.h>
#include <stdlib.h>
#include <testfunksjoner.h>
//#include <variabler.h>
#include <variabler_ext.h>


/* Variabler -------------------------------------------------- */



/* Funksjoner -------------------------------------------------- */

void behandle_paadrag(void){
	paadrags_filter();

	totalbidrag.hhf = styrebidrag.hhf + stampbidrag.hhf + rullbidrag.hhf + hivbidrag.hhf;
	totalbidrag.hhb = styrebidrag.hhb + stampbidrag.hhb + rullbidrag.hhb + hivbidrag.hhb;
	totalbidrag.hvb = styrebidrag.hvb + stampbidrag.hvb + rullbidrag.hvb + hivbidrag.hvb;
	totalbidrag.hvf = styrebidrag.hvf + stampbidrag.hvf + rullbidrag.hvf + hivbidrag.hvf;
	totalbidrag.vhf = styrebidrag.vhf + stampbidrag.vhf + rullbidrag.vhf + hivbidrag.vhf;
	totalbidrag.vhb = styrebidrag.vhb + stampbidrag.vhb + rullbidrag.vhb + hivbidrag.vhb;
	totalbidrag.vvb = styrebidrag.vvb + stampbidrag.vvb + rullbidrag.vvb + hivbidrag.vvb;
	totalbidrag.vvf = styrebidrag.vvf + stampbidrag.vvf + rullbidrag.vvf + hivbidrag.vvf;

	thruster_retning_korreksjon();
	skaler_paadrag();
	effekt_kontroll();

	thruster_PWM.hhf = (int16_t) (NEUTRAL + gain*totalbidrag.hhf);
	thruster_PWM.hhb = (int16_t) (NEUTRAL + gain*totalbidrag.hhb);
	thruster_PWM.hvb = (int16_t) (NEUTRAL + gain*totalbidrag.hvb);
	thruster_PWM.hvf = (int16_t) (NEUTRAL + gain*totalbidrag.hvf);
	thruster_PWM.vhf = (int16_t) (NEUTRAL + gain*totalbidrag.vhf);
	thruster_PWM.vhb = (int16_t) (NEUTRAL + gain*totalbidrag.vhb);
	thruster_PWM.vvb = (int16_t) (NEUTRAL + gain*totalbidrag.vvb);
	thruster_PWM.vvf = (int16_t) (NEUTRAL + gain*totalbidrag.vvf);

	oppdater_ledlys();
	skriv_thruster_PWM();


	thrusterdata.hhf = (int8_t) (gain*totalbidrag.hhf/4);
	thrusterdata.hhb = (int8_t) (gain*totalbidrag.hhb/4);
	thrusterdata.hvb = (int8_t) (gain*totalbidrag.hvb/4);
	thrusterdata.hvf = (int8_t) (gain*totalbidrag.hvf/4);
	thrusterdata.vhf = (int8_t) (gain*totalbidrag.vhf/4);
	thrusterdata.vhb = (int8_t) (gain*totalbidrag.vhb/4);
	thrusterdata.vvb = (int8_t) (gain*totalbidrag.vvb/4);
	thrusterdata.vvf = (int8_t) (gain*totalbidrag.vvf/4);

}

void oppdater_styrebidrag(void){
	// Regner ut argument og modulus av jag og svai
	styreretning = atan2(styremelding.svai, styremelding.jag);
	maks_paadrag = sqrt(styremelding.jag*styremelding.jag + styremelding.svai*styremelding.svai);

	// Utregning av pådragsnivå til hver horisontale thruster
	styrebidrag.hhf = cos(HR_kompass_rad.NW - styreretning)*maks_paadrag;
	styrebidrag.hhb = cos(HR_kompass_rad.SW - styreretning)*maks_paadrag;
	styrebidrag.hvb = - styrebidrag.hhf; 			// thrusteren er orientert 180 grader på hhf
	styrebidrag.hvf = - styrebidrag.hhb; 			// thrusteren er orientert 180 grader på hhb


	// Skalering i tilfelle gir-pådrag som kan akkumulere pådraget over "100%"
	if (styremelding.gir){
		gir = styremelding.gir * param.demping.gir;
		styrebidrag.hhf -= gir;
		styrebidrag.hhb += gir;
		styrebidrag.hvb -= gir;
		styrebidrag.hvf += gir;
	}

	// Bidrag til vertikale thrustere i tilfelle hiv
	if (styremelding.hiv){
		flagg.hiv_pause = 1;
		flagg.hpid = 0;
		teller_reg_hiv = 0;
		hiv = styremelding.hiv * param.demping.hiv;
		styrebidrag.vhf = hiv;
		styrebidrag.vhb = hiv;
		styrebidrag.vvb = hiv;
		styrebidrag.vvf = hiv;
	}
	else{
		styrebidrag.vhf = 0;
		styrebidrag.vhb = 0;
		styrebidrag.vvb = 0;
		styrebidrag.vvf = 0;
	}

	// Pådragsbegresning fra topside
	if (styremelding.throttling){gain = (100-styremelding.throttling)/25;}
	else{						 gain = 4;}
}


void paadrags_filter(void){
	styrebidrag.hhf = styrefilter.hhf * param.demping.pfa + param.demping.pfb * styrebidrag.hhf;
	styrebidrag.hhb = styrefilter.hhb * param.demping.pfa + param.demping.pfb * styrebidrag.hhb;
	styrebidrag.hvb = styrefilter.hvb * param.demping.pfa + param.demping.pfb * styrebidrag.hvb;
	styrebidrag.hvf = styrefilter.hvf * param.demping.pfa + param.demping.pfb * styrebidrag.hvf;
	styrebidrag.vhf = styrefilter.vhf * param.demping.pfa + param.demping.pfb * styrebidrag.vhf;
	styrebidrag.vhb = styrefilter.vhb * param.demping.pfa + param.demping.pfb * styrebidrag.vhb;
	styrebidrag.vvb = styrefilter.vvb * param.demping.pfa + param.demping.pfb * styrebidrag.vvb;
	styrebidrag.vvf = styrefilter.vvf * param.demping.pfa + param.demping.pfb * styrebidrag.vvf;

	styrefilter.hhf = styrebidrag.hhf;
	styrefilter.hhb = styrebidrag.hhb;
	styrefilter.hvb = styrebidrag.hvb;
	styrefilter.hvf = styrebidrag.hvf;
	styrefilter.vhf = styrebidrag.vhf;
	styrefilter.vhb = styrebidrag.vhb;
	styrefilter.vvb = styrebidrag.vvb;
	styrefilter.vvf = styrebidrag.vvf;
}

void manipulator_styring(void){
	uint8_t COM = styremelding.manipulator; // 
	if (COM & MAN_ON){
//		if(COM & MAN_RESET){		// reset funksjon (ikke impl)
//			; //utføre reset
//		}
		if(COM & MAN_KLYPE){			//  manipulatorkloen aktiv
			if(COM & MAN_KLYPE_LUKKE){	manipulator_PWM.klype = NEUTRAL-(param.demping.klype*400);}	// Lukke kloa
			else{						manipulator_PWM.klype = NEUTRAL+(param.demping.klype*400);}	// Åpne kloa
			manipulator_PWM.vri = 		NEUTRAL;
			manipulator_PWM.teleskop = 	NEUTRAL;
		}
		else if(COM & MAN_VRI){			// manipulator rotering aktiv
			if(COM & MAN_VRI_CCW){		manipulator_PWM.vri = NEUTRAL-(param.demping.vri*400);}		// kloa roterer mot klokka
			else{						manipulator_PWM.vri = NEUTRAL+(param.demping.vri*400);}		// kloa roterer med klokka
			manipulator_PWM.klype =		NEUTRAL;
			manipulator_PWM.teleskop = 	NEUTRAL;
		}
		else if(COM & MAN_TELESKOP){	// manipulator rotering aktiv
			if(COM & MAN_TELESKOP_UT){	manipulator_PWM.teleskop = NEUTRAL+(param.demping.teleskop*400);}		// manipulatoren går ut
			else{						manipulator_PWM.teleskop = NEUTRAL-(param.demping.teleskop*400);}		// manipulatoren går inn
			manipulator_PWM.klype =		NEUTRAL;
			manipulator_PWM.vri = 		NEUTRAL;
		}
		else{
			manipulator_PWM.klype =		NEUTRAL;
			manipulator_PWM.vri = 		NEUTRAL;
			manipulator_PWM.teleskop =	NEUTRAL;
		}
	}
	else{
		memcpy(&manipulator_PWM, &oppstart_PWM, sizeof(manipulator_sett));
	}
	skriv_manipulator_PWM();

}

void thruster_retning_korreksjon(void){  // nedskalering mtp thrusterkarakteristikk
	if (totalbidrag.hhf < -10){	totalbidrag.hhf = totalbidrag.hhf / (mk_modell.b + abs(totalbidrag.hhf)*mk_modell.a);	}
	if (totalbidrag.hhb < -10){	totalbidrag.hhb = totalbidrag.hhb / (mk_modell.b + abs(totalbidrag.hhb)*mk_modell.a);	}
	if (totalbidrag.hvb < -10){	totalbidrag.hvb = totalbidrag.hvb / (mk_modell.b + abs(totalbidrag.hvb)*mk_modell.a);	}
	if (totalbidrag.hvf < -10){	totalbidrag.hvf = totalbidrag.hvf / (mk_modell.b + abs(totalbidrag.hvf)*mk_modell.a);	}

	if (totalbidrag.vhf > 10){	totalbidrag.vhf = totalbidrag.vhf/ (mk_modell.b + totalbidrag.vhf*mk_modell.a);	}
	if (totalbidrag.vhb > 10){	totalbidrag.vhb = totalbidrag.vhb/ (mk_modell.b + totalbidrag.vhb*mk_modell.a);	}
	if (totalbidrag.vvb > 10){	totalbidrag.vvb = totalbidrag.vvb/ (mk_modell.b + totalbidrag.vvb*mk_modell.a);	}
	if (totalbidrag.vvf > 10){	totalbidrag.vvf = totalbidrag.vvf/ (mk_modell.b + totalbidrag.vvf*mk_modell.a);	}
}

void skaler_paadrag(void){
	t_skalering.ph = 1.0;
	t_skalering.pv = 1.0;
	t_skalering.hhf = 1.0;
	t_skalering.hhb = 1.0;
	t_skalering.hvb = 1.0;
	t_skalering.hvf = 1.0;
	t_skalering.vhf = 1.0;
	t_skalering.vhb = 1.0;
	t_skalering.vvb = 1.0;
	t_skalering.vvf = 1.0;


	if(abs(totalbidrag.hhf)>100){	t_skalering.hhf = 100.0 / abs(totalbidrag.hhf);	}
	if(abs(totalbidrag.hhb)>100){	t_skalering.hhb = 100.0 / abs(totalbidrag.hhb);	}
	if(abs(totalbidrag.hvb)>100){	t_skalering.hvb = 100.0 / abs(totalbidrag.hvb);	}
	if(abs(totalbidrag.hvf)>100){	t_skalering.hvf = 100.0 / abs(totalbidrag.hvf);	}
	if(abs(totalbidrag.vhf)>100){	t_skalering.vhf = 100.0 / abs(totalbidrag.vhf);	}
	if(abs(totalbidrag.vhb)>100){	t_skalering.vhb = 100.0 / abs(totalbidrag.vhb);	}
	if(abs(totalbidrag.vvb)>100){	t_skalering.vvb = 100.0 / abs(totalbidrag.vvb);	}
	if(abs(totalbidrag.vvf)>100){	t_skalering.vvf = 100.0 / abs(totalbidrag.vvf);	}

	if(t_skalering.ph > t_skalering.hhf){			t_skalering.ph = t_skalering.hhf;		}
	if(t_skalering.ph > t_skalering.hhb){			t_skalering.ph = t_skalering.hhb;		}
	if(t_skalering.ph > t_skalering.hvb){			t_skalering.ph = t_skalering.hvb;		}
	if(t_skalering.ph > t_skalering.hvf){			t_skalering.ph = t_skalering.hvf;		}
	if(t_skalering.pv > t_skalering.vhf){			t_skalering.pv = t_skalering.vhf;		}
	if(t_skalering.pv > t_skalering.vhb){			t_skalering.pv = t_skalering.vhb;		}
	if(t_skalering.pv > t_skalering.vvb){			t_skalering.pv = t_skalering.vvb;		}
	if(t_skalering.pv > t_skalering.vvf){			t_skalering.pv = t_skalering.vvf;		}

	if(t_skalering.ph < 1.0){
		totalbidrag.hhf *= t_skalering.ph;
		totalbidrag.hhb *= t_skalering.ph;
		totalbidrag.hvb *= t_skalering.ph;
		totalbidrag.hvf *= t_skalering.ph;
	}
	if(t_skalering.pv < 1.0){
		totalbidrag.vhf *= t_skalering.pv;
		totalbidrag.vhb *= t_skalering.pv;
		totalbidrag.vvb *= t_skalering.pv;
		totalbidrag.vvf *= t_skalering.pv;
	}
}

void skriv_thruster_PWM(void){		// Skriver ny pulsbredde for PWM-signalet til hver respektive Compare Register.
	TIM2->CCR1 = thruster_PWM.hhf;  		// HHF
	TIM2->CCR2 = thruster_PWM.hhb;  		// HHB
	TIM2->CCR3 = thruster_PWM.hvb;  		// HVB
	TIM2->CCR4 = thruster_PWM.hvf;  		// HVF
	TIM3->CCR1 = thruster_PWM.vhf;  		// VHF
	TIM3->CCR2 = thruster_PWM.vhb;  		// VHB
	TIM3->CCR3 = thruster_PWM.vvb;  		// VVB
	TIM3->CCR4 = thruster_PWM.vvf;  		// VVF
}

void skriv_manipulator_PWM(void){	// Skriver ny pulsbredde for PWM-signalet til hver respektive Compare Register.
	manipulator_PWM.teleskop = manipulator_filter.teleskop * param.demping.pfa + param.demping.pfb * manipulator_PWM.teleskop;
	manipulator_PWM.vri = manipulator_filter.vri * param.demping.pfa + param.demping.pfb * manipulator_PWM.vri;
	manipulator_PWM.klype = manipulator_filter.klype * param.demping.pfa + param.demping.pfb * manipulator_PWM.klype;

	TIM4->CCR1 = manipulator_PWM.teleskop;	// Teleskop
	TIM4->CCR2 = manipulator_PWM.vri;	// Rull
	TIM4->CCR3 = manipulator_PWM.klype;	// Klype

	manipulator_filter.teleskop = manipulator_PWM.teleskop;
	manipulator_filter.vri = manipulator_PWM.vri;
	manipulator_filter.klype = manipulator_PWM.klype;
}

void effekt_kontroll(void){
	if(effekt_forbruk.thruster_12v > 10000){
		gain *= 0.8;
	}
}

void sjekk_brytertrykk(void){
	if (GPIOA->IDR & GPIO_PIN_0 ) { 			// Sjekker om bryteren er trykket inn
       if(!forrige_bryterstatus) { 				// Var bryteren trykket inn sist kontrollsjekk
    	   forrige_bryterstatus = 1;
    	   brytertrykk = 1;      				// Nytt brytertrykk registrert
       }
	}
    else {                 						// Hvis bryteren ikke er trykket inn
    	 forrige_bryterstatus = 0; 				// Bryterstatus settes til 0.
    }
}


void oppdater_ledlys(void){
	if((thruster_PWM.hhf > 1520) || ((thruster_PWM.hhf < 1480) && led_status)){
			GPIOE->ODR |= LED_HHF;	}
	else{	GPIOE->ODR &= ~LED_HHF;	}
	if((thruster_PWM.hhb > 1520) || ((thruster_PWM.hhb < 1480) && led_status)){
			GPIOE->ODR |= LED_HHB;	}
	else{	GPIOE->ODR &= ~LED_HHB;	}
	if((thruster_PWM.hvb > 1520) || ((thruster_PWM.hvb < 1480) && led_status)){
			GPIOE->ODR |= LED_HVB;	}
	else{	GPIOE->ODR &= ~LED_HVB;	}
	if((thruster_PWM.hvf > 1520) || ((thruster_PWM.hvf < 1480) && led_status)){
			GPIOE->ODR |= LED_HVF;	}
	else{	GPIOE->ODR &= ~LED_HVF;	}
	if((thruster_PWM.vhf > 1520) || ((thruster_PWM.vhf < 1480) && led_status)){
			GPIOE->ODR |= LED_VHF;	}
	else{	GPIOE->ODR &= ~LED_VHF;	}
	if((thruster_PWM.vhb > 1520) || ((thruster_PWM.vhb < 1480) && led_status)){
			GPIOE->ODR |= LED_VHB;	}
	else{	GPIOE->ODR &= ~LED_VHB;	}
	if((thruster_PWM.vvb > 1520) || ((thruster_PWM.vvb < 1480) && led_status)){
			GPIOE->ODR |= LED_VVB;	}
	else{	GPIOE->ODR &= ~LED_VVB;	}
	if((thruster_PWM.vvf > 1520) || ((thruster_PWM.vvf < 1480) && led_status)){
			GPIOE->ODR |= LED_VVF;	}
	else{	GPIOE->ODR &= ~LED_VVF;	}
}

float kg_til_paadrag(float kg_thrust){
	float kg_float = (float) (fabs(kg_thrust));
	float paadrag = (24.44*kg_float*kg_float+39.94*kg_float + 0.0)/(kg_float+0.21); // + 0.52
	if(kg_thrust<0.0){
		return -paadrag;	}
	else {
		return paadrag;		}
}


/*
%      f(x) = (p1*x^2 + p2*x + p3) / (x + q1)
% Coefficients (with 95% confidence bounds):
%        p1 =       24.44  (17.37, 31.51)
%        p2 =       39.94  (11.68, 68.2)
%        p3 =      0.5184  (-1.446, 2.482)
%        q1 =      0.2079  (-0.1737, 0.5895)
*/
// Konvertering av kvadratisk styrefelt til sirkulært
//	int16_t jag = (int16_t) styremelding.jag *sqrt(1-((styremelding.svai/100)^2)/2);
//	int16_t svai = (int16_t) styremelding.svai *sqrt(1-((styremelding.jag/100)^2)/2);
