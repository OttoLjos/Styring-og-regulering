/*
 * verdier.c
 *
 *  Created on: Mar 28, 2022
 *      Author: trcho
 */


#include "main.h"
#include <math.h>
#include <structures.h>
#include <funksjoner.h>
#include <string.h>
#include <stdlib.h>
#include <testfunksjoner.h>
//#include <variabler.h>
#include <variabler_ext.h>



void oppstartsverdier(void){
	param.demping.gir = 0.5;
	param.demping.hiv = 0.6;
	param.demping.klype = 0.35;
	param.demping.vri = 0.25;
	param.demping.teleskop = 0.5;
	param.demping.pfa = 0.8;
	param.demping.pfb = 1 - param.demping.pfa;
	gain = 4;
	styreretning = 0.0;
	forrige_bryterstatus = 0;
	brytertrykk = 0;
	float HR_rad[8] = {0, M_PI/4, M_PI/2, 3*M_PI/4, M_PI, -3*M_PI/4, -M_PI/2, -M_PI/4};
//	int32_t null8[8] = {0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};
	memcpy(&HR_kompass_rad, &HR_rad, sizeof(kompass));
//	uint16_t oppstart_PWM[8] = {NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL};
	memcpy(&thruster_PWM, &oppstart_PWM, sizeof(thruster_sett));
	memcpy(&manipulator_PWM, &oppstart_PWM, sizeof(manipulator_sett));
	memcpy(&styrebidrag, &null8, sizeof(thruster_sett));
	memcpy(&totalbidrag, &null8, sizeof(thruster_sett));
	memcpy(&stampbidrag, &null8, sizeof(thruster_sett));
	memcpy(&rullbidrag, &null8, sizeof(thruster_sett));
	memcpy(&hivbidrag, &null8, sizeof(thruster_sett));
	mk_modell.a = 0.0024;
	mk_modell.b = 1;

	spid.yr = 0.0;
	rpid.yr = 0.0;
	hpid.yr = 0.0;

	param.hiv_pid.a = 0.9;
	param.hiv_pid.b = 1-param.hiv_pid.a;
	param.hiv_pid.dz = 0;
	param.hiv_pid.kp = 1.049;
	param.hiv_pid.ki = 0.45;
	param.hiv_pid.kd = 0.425;
	param.hiv_pid.ts = 0.05;
	param.hiv_pid.ui_min = -1.0;
	param.hiv_pid.ui_maks = 1.0;
	param.hiv_pid.ut_min = -1.0;
	param.hiv_pid.ut_maks = 1.0;

	param.rull_pid.a = 0.9;
	param.rull_pid.b = 1-param.rull_pid.a;
	param.rull_pid.dz = 0;
	param.rull_pid.kp = 0.0473;
	param.rull_pid.ki = 0.0; // 0.287;
	param.rull_pid.kd = 0.0375;
	param.rull_pid.ts = 0.05;
	param.rull_pid.ui_min = -0.5;
	param.rull_pid.ui_maks = 0.5;
	param.rull_pid.ut_min = -0.5;
	param.rull_pid.ut_maks = 0.5;

	param.stamp_pid.a = 0.9;
	param.stamp_pid.b = 1-param.stamp_pid.a;
	param.stamp_pid.dz = 0;
	param.stamp_pid.kp = 0.089;
	param.stamp_pid.ki = 0.0; //0.353;
	param.stamp_pid.kd = 0.074;
	param.stamp_pid.ts = 0.05;
	param.stamp_pid.ui_min = -0.6;
	param.stamp_pid.ui_maks = 0.6;
	param.stamp_pid.ut_min = -0.6;
	param.stamp_pid.ut_maks = 0.6;
}

void oppdater_parameter(uint32_t param_id, float parameter){
	switch(param_id){
	case 2:
//		flagg.regulering = !flagg.regulering;
		break;
	case 3:
		if(!flagg.hiv_pause){
			flagg.hpid = !flagg.hpid;
			if(!flagg.hpid){memcpy(&hivbidrag, &null8, sizeof(thruster_sett_float));}
			hpid.yr = gyrodata.hiv/100;
			hpid.ui = 0;
			hpid.uis = 0;
		}
		break;
	case 4:
		flagg.rpid = !flagg.rpid;
		if(!flagg.rpid){memcpy(&rullbidrag, &null8, sizeof(thruster_sett_float));}
		rpid.ui = 0;
		rpid.uis = 0;
		break;
	case 5:
		flagg.spid = !flagg.spid;
		if(!flagg.spid){memcpy(&stampbidrag, &null8, sizeof(thruster_sett_float));}
		spid.ui = 0;
		spid.uis = 0;
		break;
	case 10:
		param.demping.gir = (float) parameter;			break;
	case 11:
		param.demping.hiv = (float) parameter;			break;
	case 12:
		param.demping.teleskop = (float) parameter;		break;
	case 13:
		param.demping.vri = (float) parameter;			break;
	case 14:
		param.demping.klype = (float) parameter;		break;
	case 15:
		param.demping.pfa = (float) parameter;
		param.demping.pfb = 1 - (float) parameter;		break;
	case 30:
		param.hiv_pid.kp = (float) parameter;			break;
	case 31:
		param.hiv_pid.ki = (float) parameter;			break;
	case 32:
		param.hiv_pid.kd = (float) parameter;			break;
	case 33:
		param.hiv_pid.ui_min = (float) -parameter;				// begrensning av kg pådrag pr thruster
		param.hiv_pid.ui_maks = (float) parameter;		break;
	case 34:
		param.hiv_pid.ut_min = (float) -parameter;				// begrensning av kg pådrag pr thruster
		param.hiv_pid.ut_maks = (float) parameter;		break;
	case 35:
		hpid.yr += (float) parameter;					break; 	// dybdeendring i meter
	case 36:
		param.hiv_pid.a = parameter;							// filterparameter for derivatorledd
		param.hiv_pid.b = 1-param.hiv_pid.a;			break;
	case 40:
		param.rull_pid.kp = (float) parameter;			break;
	case 41:
		param.rull_pid.ki = (float) parameter;			break;
	case 42:
		param.rull_pid.kd = (float) parameter;			break;
	case 43:
		param.rull_pid.ui_min = (float) -parameter;				// begrensning av kg pådrag pr thruster
		param.rull_pid.ui_maks = (float) parameter;		break;
	case 44:
		param.rull_pid.ut_min = (float) -parameter;				// begrensning av kg pådrag pr thruster
		param.rull_pid.ut_maks = (float) parameter;		break;
	case 45:
		rpid.yr = (float) (parameter*M_PI/180);			break; 	// rullvinkel-referanse i grader
	case 46:
		param.rull_pid.a = parameter;							// filterparameter for derivatorledd
		param.rull_pid.b = 1-param.rull_pid.a;			break;
	case 50:
		param.stamp_pid.kp = (float) parameter;			break;
	case 51:
		param.stamp_pid.ki = (float) parameter;			break;
	case 52:
		param.stamp_pid.kd = (float) parameter;			break;
	case 53:
		param.stamp_pid.ui_min = (float) -parameter;			// begrensning av kg pådrag pr thruster
		param.stamp_pid.ui_maks = (float) parameter;	break;
	case 54:
		param.stamp_pid.ut_min = (float) -parameter;			// begrensning av kg pådrag pr thruster
		param.stamp_pid.ut_maks = (float) parameter;	break;
	case 55:
		spid.yr = (float) (parameter*M_PI/180);			break; 	// stampvinkel-referanse i grader
	case 56:
		param.stamp_pid.a = parameter;							// filterparameter for derivatorledd
		param.stamp_pid.b = 1-param.stamp_pid.a;		break;
	case 100:
		mk_modell.a = (float) parameter;				break;
	case 101:
		mk_modell.b = (float) parameter;				break;
	case 301:
		flagg.test_thrustere = 1;
		thruster_ID = (uint8_t) parameter;				break;
	}
}

