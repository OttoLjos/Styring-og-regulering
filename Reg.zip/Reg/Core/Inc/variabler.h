/*
 * variable_decl.h
 *
 *  Created on: Mar 22, 2022
 *      Author: trcho
 */

#ifndef INC_VARIABLER_H_
#define INC_VARIABLER_H_

#include <main.h>
#include "structures.h"


int32_t null8[8];// = {0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000};
uint16_t oppstart_PWM[8]; // = {NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL};

 FLAGG_struct flagg;
 uint8_t hiv_FLAGG;
//
 uint8_t teller_reg_hiv;
 uint8_t teller_bryter;
//	uint8_t teller_bryter = 0;
//	uint8_t teller_reg_hiv = 0;
 uint16_t teller_diode;
 uint16_t teller_test_thruster;
 uint16_t teller_idle;
 uint8_t test_reg;
 uint32_t teller_test_reg;

 uint8_t thruster_ID;
 uint8_t forrige_bryterstatus;
 uint8_t brytertrykk;

 uint8_t led_status;

 volatile float styreretning, maks_paadrag, skalering, gir, hiv, gain, hiv_m, rull_m, stamp_m;
 styrestruct styremelding;
 thruster_sett thruster_PWM;
 thruster_datastruct thrusterdata;
 manipulator_sett manipulator_PWM, manipulator_filter;
 gyrostruct gyrodata;
 akselerasjonsstruct aksdata;
 kompass HR_kompass_rad;
 thruster_sett_float totalbidrag, styrebidrag, stampbidrag, rullbidrag, hivbidrag, styrefilter;
 effekt_struct effekt_forbruk;

 parameter_struct param;

 pid_variabler spid, rpid, hpid;

can_param ny_param;
thruster_skalering t_skalering;
motor_karakteristikk_modell mk_modell;


#endif /* INC_VARIABLER_H_ */
