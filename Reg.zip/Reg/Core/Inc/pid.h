/*
 * pid.h
 *
 *  Created on: Feb 3, 2022
 *      Author: trcho
 */

#ifndef INC_PID_H_
#define INC_PID_H_

/* Includes --------------------------------------------------- */

/* Variables -------------------------------------------------- */

extern volatile float styreretning;

/* Private funksjonsprototyper -------------------------------- */

void stamp_regulator(void);
void rull_regulator(void);
void hiv_regulator(void);




/* Private funksjonsdeklarasjoner ----------------------------- */

#endif /* INC_PID_H_ */
