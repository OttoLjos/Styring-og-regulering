/*
 * structures.h
 *
 *  Created on: Jan 20, 2022
 *      Author: trcho
 */

#ifndef INC_STRUCTURES_H_
#define INC_STRUCTURES_H_

#include "main.h"
//#include <variabler.h>


//typedef struct {
//	innhold;
//} navn;

typedef struct {
	int8_t jag; 		// x-retning
	int8_t svai;		// y-retning
	int8_t hiv;			// z-retning
	int8_t gir;			// rotasjon
	int8_t manipulator;	// manipulator '0b reset on grab release cw ccw ut inn'
	int8_t ledig_1;		// not defined
	int8_t reg;			// Flagg for regulering LSB++: Rull | Stamp | Hiv
	int8_t throttling;	// paadragsbegrensning
} styrestruct;

typedef struct{
	uint8_t flagg;
} flagg_8b;

typedef struct {
	float a; 						// stigningsrate
	float b; 						// konstantledd
}  motor_karakteristikk_modell;		// 1. ordens modell for kompensering av motorkarakteristikken
									// siden propellen er mer effektiv en retning.

typedef struct {
	float ph;		// skalering for pådrag horisontalt
	float pv;		// skalering for pådrag vertikalt
	float hhf;		// HHF proporsjonalt med makspådrag
	float hhb;		// HHB proporsjonalt med makspådrag
	float hvb;		// HVB proporsjonalt med makspådrag
	float hvf;		// HVF proporsjonalt med makspådrag
	float vhf;		// VHF proporsjonalt med makspådrag
	float vhb;		// VHB proporsjonalt med makspådrag
	float vvb;		// VVB proporsjonalt med makspådrag
	float vvf;		// VVF proporsjonalt med makspådrag
} thruster_skalering;		// thrusterskalering


typedef struct {
	uint32_t param_id;
	float parameter;
} can_param;

typedef struct{
	float hiv;
	float gir;
	float teleskop;
	float vri;
	float klype;
	float pfa; 			//pådragsfilter a
	float pfb;			//pådragsfilter 1-a
} styredemping;

typedef struct{
	float kp;			// Proporsjonalforsterkning
	float ki;			// Integratorforsterkning
	float kd;			// Derivatorforsterkning
	float ts;			// tidskonstant
	float dz;			// deadzone
	float a;			// IIR Filterkoeffisient
	float b; 			// IIR Invers filterkoeffisient (1-a)
	float ui_maks;		// Integratorbegrensning tak
	float ui_min;		// Integratorbegrensning gulv
	float ut_maks;		// Totalpådragsbegrensning tak
	float ut_min;		// Totalpådragsbegrensning gulv
} pid_param;

typedef struct{
	float yr;			// Inngangsreferanse
	float e;			// Avvik (error)
	float es;			// Forrige avvik
	float up;			// Proporsjonalpådrag
	float ui;			// Integratorpådrag
	float uis;			// Forrige Integratorpådrag
	float ud;			// Derivatorpådrag
	float uds;			// Forrige Derivatorpådrag
	float fbf;			// Feedback Filtrert (Måling filtrert i IIR)
	float fbfs;			// Forrige Feedback Filtrert
	float ut;			// Totalpådrag up+ui+ud
} pid_variabler;

typedef struct{
	styredemping demping;
	pid_param rull_pid;
	pid_param hiv_pid;
	pid_param stamp_pid;
} parameter_struct;


typedef struct {
	int16_t hiv;	// dybdeposisjon i cm
	int16_t rull;	// rullvinkel i tidels grader
	int16_t stamp;	// stampvinkel i tidels grader
	int16_t gir;	// girvinkel (ikke aktiv)
} gyrostruct;

typedef struct{
	int16_t x;
	int16_t y;
	int16_t z;
	int16_t ledig;
} akselerasjonsstruct;

typedef struct {
	uint8_t regulering;	// reguleringsflagg
	uint8_t hiv_pause;	// reguleringspause når dybden endres
	uint8_t spid;		// stamp-reguleringsflagg
	uint8_t rpid;		// rull-reguleringsflagg
	uint8_t hpid;		// hiv-reguleringsflagg
	uint8_t can_70;		// Mottatt styredata over CAN
	uint8_t can_71;		// Mottatt ny verdi for parameter
	uint8_t can_80;		// Mottatt Gyrodata fra sensornode
	uint8_t can_81;		// Mottatt akselerasjonsdata fra sensornoden
	uint8_t can_82;
	uint8_t can_90;		// Mottatt strømdata
	uint8_t can_91;
	uint8_t test_thrustere; // testfunksjon for thrustere
	uint8_t testfunksjon;	// testfunksjon kjører
}FLAGG_struct;

typedef struct {
	int16_t hhf;
	int16_t hhb;
	int16_t hvb;
	int16_t hvf;
	int16_t vhf;
	int16_t vhb;
	int16_t vvb;
	int16_t vvf;
} thruster_sett;

typedef struct {
	int8_t hhf;
	int8_t hhb;
	int8_t hvb;
	int8_t hvf;
	int8_t vhf;
	int8_t vhb;
	int8_t vvb;
	int8_t vvf;
} thruster_datastruct;

typedef struct {
	float hhf;
	float hhb;
	float hvb;
	float hvf;
	float vhf;
	float vhb;
	float vvb;
	float vvf;
} thruster_sett_float;

typedef struct {
	int16_t teleskop;
	int16_t vri;
	int16_t klype;
} manipulator_sett;

typedef struct {
	float N;
	float NE;
	float E;
	float SE;
	float S;
	float SW;
	float W;
	float NW;
} kompass;

typedef struct {
	uint16_t thruster_12v;
	uint16_t manipulator_12v;
	uint16_t elektronikk_5v;
	uint16_t tom;	
} effekt_struct;

#endif /* INC_STRUCTURES_H_ */
