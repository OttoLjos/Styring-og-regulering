/*
 * funksjoner.h
 *
 *  Created on: Jan 18, 2022
 *      Author: trcho
 */

#ifndef INC_FUNKSJONER_H_
#define INC_FUNKSJONER_H_

/* Includes --------------------------------------------------- */


/* Variables -------------------------------------------------- */

//extern volatile float styreretning;

/* Private funksjonsprototyper -------------------------------- */

void skriv_thruster_PWM(void);
void skriv_manipulator_PWM(void);
void oppdater_LED_moenster(void);
void sjekk_brytertrykk(void);
void behandle_paadrag(void);
void oppdater_styrebidrag(void);
void oppdater_ledlys(void);
void oppstartsverdier(void);
void oppdater_parameter(uint32_t param_id, float parameter);
void manipulator_styring(void);
float kg_til_paadrag(float kg_thrust);
void skaler_paadrag(void);
void thruster_retning_korreksjon(void);
void effekt_kontroll(void);
void paadrags_filter(void);
/* Private funksjonsdeklarasjoner ----------------------------- */


/* Includes ----------------------------------------- */

#endif /* INC_FUNKSJONER_H_ */


